
import React, { useEffect, useState } from 'react';

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    
    // Enhanced fade-in animation on scroll
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fadeInUp');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.fade-section').forEach(section => {
      observer.observe(section);
    });

    // Parallax effect for hero section
    const handleScroll = () => {
      const scrolled = window.pageYOffset;
      const heroElements = document.querySelectorAll('.parallax');
      heroElements.forEach(element => {
        const speed = element.dataset.speed;
        element.style.transform = `translateY(${scrolled * speed}px)`;
      });
    };

    window.addEventListener('scroll', handleScroll);

    // Floating particles effect
    const createParticles = () => {
      const particlesContainer = document.querySelector('.particles-container');
      if (particlesContainer) {
        for (let i = 0; i < 50; i++) {
          const particle = document.createElement('div');
          particle.className = 'particle';
          particle.style.left = Math.random() * 100 + '%';
          particle.style.animationDelay = Math.random() * 20 + 's';
          particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
          particlesContainer.appendChild(particle);
        }
      }
    };

    createParticles();

    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-950 text-white font-sans overflow-x-hidden relative">
      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          25% { transform: translateY(-10px) rotate(1deg); }
          50% { transform: translateY(-20px) rotate(0deg); }
          75% { transform: translateY(-10px) rotate(-1deg); }
        }
        
        @keyframes glow {
          0%, 100% { 
            box-shadow: 0 0 30px rgba(59, 130, 246, 0.4), 0 0 60px rgba(37, 99, 235, 0.2); 
          }
          50% { 
            box-shadow: 0 0 50px rgba(59, 130, 246, 0.8), 0 0 100px rgba(37, 99, 235, 0.4); 
          }
        }
        
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        
        @keyframes ripple {
          0% { transform: scale(0); opacity: 1; }
          100% { transform: scale(4); opacity: 0; }
        }
        
        @keyframes particleFloat {
          0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
        }
        
        .animate-fadeInUp {
          animation: fadeInUp 0.8s ease-out forwards;
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-glow {
          animation: glow 3s ease-in-out infinite;
        }
        
        .animate-pulse {
          animation: pulse 2s ease-in-out infinite;
        }
        
        .animate-shimmer {
          animation: shimmer 2s linear infinite;
        }
        
        .animate-ripple {
          animation: ripple 1s ease-out;
        }
        
        .glass-morphism {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.05));
          backdrop-filter: blur(20px);
          border: 1px solid rgba(59, 130, 246, 0.2);
          box-shadow: 0 8px 32px rgba(59, 130, 246, 0.1);
        }
        
        .glass-morphism-strong {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(37, 99, 235, 0.1));
          backdrop-filter: blur(25px);
          border: 1px solid rgba(59, 130, 246, 0.3);
          box-shadow: 0 12px 40px rgba(59, 130, 246, 0.2);
        }
        
        .gradient-text {
          background: linear-gradient(45deg, #3B82F6, #06B6D4, #0EA5E9, #1D4ED8);
          background-size: 300% 300%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: gradient 4s ease infinite;
        }
        
        .gradient-border {
          background: linear-gradient(45deg, #3B82F6, #06B6D4, #0EA5E9, #1D4ED8);
          background-size: 300% 300%;
          animation: gradient 4s ease infinite;
        }
        
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        .hover-lift {
          transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        .hover-lift:hover {
          transform: translateY(-10px) scale(1.02);
          box-shadow: 0 20px 40px rgba(59, 130, 246, 0.3);
        }
        
        .shimmer-effect {
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
          background-size: 200% 100%;
        }
        
        .particle {
          position: absolute;
          width: 4px;
          height: 4px;
          background: radial-gradient(circle, #3B82F6, #06B6D4);
          border-radius: 50%;
          animation: particleFloat linear infinite;
          pointer-events: none;
        }
        
        .particles-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
        }
        
        .neo-morphism {
          background: linear-gradient(145deg, #1e3a8a, #1e40af);
          box-shadow: 20px 20px 40px #0f172a, -20px -20px 40px #2563eb;
        }
        
        .cyber-grid {
          background-image: 
            linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px);
          background-size: 50px 50px;
        }
        
        .hologram-effect {
          background: linear-gradient(45deg, transparent 30%, rgba(59, 130, 246, 0.1) 50%, transparent 70%);
          background-size: 200% 200%;
          animation: shimmer 3s linear infinite;
        }
      `}</style>

      {/* Particles Background */}
      <div className="particles-container"></div>

      {/* Cyber Grid Background */}
      <div className="fixed inset-0 cyber-grid opacity-30 pointer-events-none"></div>

      {/* Navigation */}
      <nav className="glass-morphism-strong fixed w-full z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="relative">
                <span className="text-2xl font-bold gradient-text">Yousef Abdellatif</span>
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg blur opacity-25 animate-pulse"></div>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              {['About', 'Experience', 'Education', 'Certifications', 'Skills', 'Contact'].map((item) => (
                <a 
                  key={item}
                  href={`#${item.toLowerCase()}`} 
                  className="py-2 px-4 rounded-md text-sm font-medium hover:text-blue-400 transition-all duration-300 relative group hover-lift"
                >
                  {item}
                  <span className="absolute bottom-0 left-0 w-0 h-1 bg-gradient-to-r from-blue-400 to-cyan-400 group-hover:w-full transition-all duration-300 rounded-full"></span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-md opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-16 fade-section relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/30 to-cyan-800/30"></div>
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <div className="parallax" data-speed="0.1">
                <div className="relative">
                  <h1 className={`text-6xl md:text-8xl font-bold mb-8 transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                    <span className="gradient-text block">Yousef Ibrahim</span>
                    <span className="text-white block hologram-effect">Jaber Abdellatif</span>
                  </h1>
                  <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg blur-2xl opacity-20 animate-pulse"></div>
                </div>
                
                <div className={`relative transition-all duration-1000 delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                  <p className="text-2xl text-blue-200 mb-8 leading-relaxed shimmer-effect">
                    🧬 Pharmacy Student | 📊 Data Science Enthusiast | 🏥 Healthcare Innovator
                  </p>
                </div>
                
                <div className={`flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6 transition-all duration-1000 delay-500 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                  <a 
                    href="https://wa.me/201068587688" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="glass-morphism-strong hover-lift px-8 py-4 rounded-full text-white font-semibold hover:bg-green-500/20 transition-all duration-300 animate-glow relative overflow-hidden group"
                  >
                    <span className="relative z-10">💬 WhatsApp</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-blue-400/20 opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                  </a>
                  <a 
                    href="#contact" 
                    className="relative overflow-hidden group px-8 py-4 rounded-full font-semibold transition-all duration-300 hover-lift"
                  >
                    <div className="absolute inset-0 gradient-border p-[2px] rounded-full">
                      <div className="bg-slate-900 rounded-full w-full h-full flex items-center justify-center">
                        <span className="gradient-text">📧 Contact</span>
                      </div>
                    </div>
                    <span className="relative gradient-text">📧 Contact</span>
                  </a>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2 flex justify-center">
              <div className="relative animate-float">
                <div className="relative">
                  <div className="w-80 h-80 rounded-full overflow-hidden shadow-2xl neo-morphism animate-glow relative">
                    <img 
                      src="https://drive.google.com/uc?export=view&id=1HxBwOBSdYl3FwN_16F3dJkrKWf-YOFdJ"
                      alt="Yousef Ibrahim Jaber Abdellatif"
                      className="w-full h-full object-cover relative z-10"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.parentElement.innerHTML = '<div class="w-full h-full bg-gradient-to-br from-blue-400 via-cyan-400 to-blue-600 flex items-center justify-center text-8xl relative overflow-hidden">👨‍⚕️<div class="absolute inset-0 hologram-effect"></div></div>';
                      }}
                    />
                    <div className="absolute inset-0 hologram-effect"></div>
                  </div>
                  <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full blur-2xl opacity-30 animate-pulse"></div>
                </div>
                
                {/* Floating elements */}
                <div className="absolute -top-8 -right-8 w-24 h-24 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-3xl animate-bounce shadow-2xl">
                  ⚡
                </div>
                <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center text-2xl animate-pulse shadow-2xl">
                  💊
                </div>
                <div className="absolute top-1/2 -left-12 w-16 h-16 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-full flex items-center justify-center text-xl animate-float shadow-2xl">
                  📊
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 fade-section relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/10 to-indigo-900/10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 gradient-text">About Me</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-blue-400/20 to-transparent rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-cyan-400/20 to-transparent rounded-tr-full"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-pulse">
                    🎯
                  </div>
                  <h3 className="text-2xl font-semibold text-blue-300">Professional Journey</h3>
                </div>
                
                <p className="text-lg text-blue-100 mb-6 leading-relaxed">
                  🎯 Dedicated and detail-oriented Pharmacy student with extensive experience in medication dispensing, patient counseling, and visual content creation. Proficient in data science and analytics, with a focus on enhancing healthcare outcomes through technology.
                </p>
                <p className="text-lg text-blue-100 leading-relaxed">
                  🚀 Proven ability to collaborate effectively in team environments while actively contributing to patient education initiatives and pharmaceutical marketing strategies. Expected to graduate in 2027, aiming to leverage knowledge in pharmacy and data analytics to advance patient care and healthcare operations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Professional Experience */}
      <section id="experience" className="py-20 fade-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 gradient-text">Professional Experience</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="max-w-5xl mx-auto space-y-8">
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-green-400/20 to-blue-400/20 rounded-bl-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400/20 to-blue-400/20 rounded-3xl blur opacity-25"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-glow">
                    💊
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold text-green-300">Intern, Community Pharmacy</h3>
                    <p className="text-blue-300 text-lg">Al-Selini Pharmacy, Sohag, Egypt | June 2023 - Present</p>
                  </div>
                </div>
                
                <ul className="space-y-4 text-blue-100">
                  <li className="flex items-start group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">✓</span>
                    <span className="group-hover:text-white transition-all duration-300">Assisted in medication dispensing and management, ensuring accuracy and compliance with healthcare regulations.</span>
                  </li>
                  <li className="flex items-start group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">✓</span>
                    <span className="group-hover:text-white transition-all duration-300">Provided patient counseling on medication use and potential side effects, enhancing patient understanding and adherence.</span>
                  </li>
                  <li className="flex items-start group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">✓</span>
                    <span className="group-hover:text-white transition-all duration-300">Collaborated with pharmacy staff to develop promotional materials, improving customer engagement and awareness.</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-blue-400/20 to-cyan-400/20 rounded-bl-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400/20 to-cyan-400/20 rounded-3xl blur opacity-25"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-glow">
                    🏥
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold text-blue-300">Volunteer, Health Awareness Campaign</h3>
                    <p className="text-cyan-300 text-lg">EPSF_SINAI, NORTH SINAI, Egypt | January 2023 - April 2023</p>
                  </div>
                </div>
                
                <ul className="space-y-4 text-blue-100">
                  <li className="flex items-start group">
                    <span className="text-blue-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">✓</span>
                    <span className="group-hover:text-white transition-all duration-300">Educated the community on preventive healthcare measures through workshops and informational sessions.</span>
                  </li>
                  <li className="flex items-start group">
                    <span className="text-blue-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">✓</span>
                    <span className="group-hover:text-white transition-all duration-300">Designed visually appealing materials for outreach programs, increasing public participation in health initiatives.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education */}
      <section id="education" className="py-20 fade-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 gradient-text">Education</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden">
              <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-yellow-400/30 to-blue-400/30 rounded-br-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-yellow-400/20 to-blue-400/20 rounded-3xl blur opacity-25"></div>
              
              <div className="relative z-10 flex items-center">
                <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-blue-500 rounded-full flex items-center justify-center text-3xl mr-6 animate-glow">
                  🎓
                </div>
                <div>
                  <h3 className="text-3xl font-semibold text-yellow-300 mb-2">Bachelor of Pharmacy</h3>
                  <p className="text-blue-300 text-lg">Sinai University, Arish, Egypt</p>
                  <p className="text-cyan-300 text-lg font-semibold">Expected Graduation: 2027</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section id="certifications" className="py-20 fade-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 gradient-text">Certifications</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "📊 Introduction to Data Science", org: "Cisco Networking Academy", date: "June 5, 2024", color: "cyan", icon: "📊" },
              { title: "🧪 Epsf_PHocus Conference", org: "Attendance", date: "May 25, 2023", color: "purple", icon: "🧪" },
              { title: "🧪 Epsf_PHocus Conference", org: "Attendance", date: "April 24, 2024", color: "indigo", icon: "🧪" },
              { title: "🏥 SUAPH Conference", org: "Attendance", date: "May 4, 2024", color: "green", icon: "🏥" },
              { title: "🛡️ Total Quality & Infection Control", org: "Medix", date: "Diploma", color: "red", icon: "🛡️" }
            ].map((cert, index) => (
              <div key={index} className="glass-morphism-strong p-6 rounded-2xl hover-lift relative overflow-hidden group">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400/20 to-cyan-400/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                <div className="relative z-10">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-r from-${cert.color}-400 to-blue-500 rounded-full flex items-center justify-center text-xl mr-4 animate-pulse`}>
                      {cert.icon}
                    </div>
                    <h3 className={`text-lg font-semibold text-${cert.color}-300 group-hover:text-white transition-all duration-300`}>
                      {cert.title}
                    </h3>
                  </div>
                  <p className="text-blue-300 group-hover:text-blue-200 transition-all duration-300">{cert.org}</p>
                  <p className="text-cyan-300 font-semibold">{cert.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills */}
      <section id="skills" className="py-20 fade-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 gradient-text">Core Competencies</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-green-400/20 to-blue-400/20 rounded-bl-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400/20 to-blue-400/20 rounded-3xl blur opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-glow">
                    💊
                  </div>
                  <h3 className="text-2xl font-semibold text-green-300">Pharmaceutical Skills</h3>
                </div>
                <ul className="space-y-4 text-blue-100">
                  <li className="flex items-center group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">⚕️</span>
                    <span className="group-hover:text-white transition-all duration-300">Medication Dispensing & Management</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">👥</span>
                    <span className="group-hover:text-white transition-all duration-300">Patient Counseling</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-green-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">🔍</span>
                    <span className="group-hover:text-white transition-all duration-300">Quality Assurance</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-blue-400/20 to-cyan-400/20 rounded-bl-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400/20 to-cyan-400/20 rounded-3xl blur opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-glow">
                    💻
                  </div>
                  <h3 className="text-2xl font-semibold text-blue-300">Technical Skills</h3>
                </div>
                <ul className="space-y-4 text-blue-100">
                  <li className="flex items-center group">
                    <span className="text-blue-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">📊</span>
                    <span className="group-hover:text-white transition-all duration-300">Data Science & Analytics</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-blue-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">🎨</span>
                    <span className="group-hover:text-white transition-all duration-300">Graphic Design (Adobe Suite)</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-blue-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">📋</span>
                    <span className="group-hover:text-white transition-all duration-300">Microsoft Office Suite</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="glass-morphism-strong p-10 rounded-3xl hover-lift relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-purple-400/20 to-blue-400/20 rounded-bl-full"></div>
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-400/20 to-blue-400/20 rounded-3xl blur opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-blue-500 rounded-full flex items-center justify-center text-2xl mr-4 animate-glow">
                    🤝
                  </div>
                  <h3 className="text-2xl font-semibold text-purple-300">Soft Skills</h3>
                </div>
                <ul className="space-y-4 text-blue-100">
                  <li className="flex items-center group">
                    <span className="text-purple-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">💬</span>
                    <span className="group-hover:text-white transition-all duration-300">Strong Communication</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-purple-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">🧩</span>
                    <span className="group-hover:text-white transition-all duration-300">Problem Solving</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-purple-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">👥</span>
                    <span className="group-hover:text-white transition-all duration-300">Team Collaboration</span>
                  </li>
                  <li className="flex items-center group">
                    <span className="text-purple-400 mr-4 text-xl group-hover:scale-125 transition-all duration-300">🔄</span>
                    <span className="group-hover:text-white transition-all duration-300">Adaptability</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="glass-morphism-strong border-t border-blue-400/20 py-16 fade-section relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-cyan-900/20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-6 gradient-text">Let's Connect</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-blue-200 mb-8 md:mb-0 text-center md:text-left">
              <p className="text-lg">&copy; {new Date().getFullYear()} Yousef Abdellatif. All rights reserved.</p>
              <p className="text-blue-300 mt-2">Crafted with 💙 and innovation</p>
              <p className="text-cyan-300 mt-3 font-semibold text-lg">Created by Yousef Ibrahim Jaber</p>
            </div>
            
            <div className="flex space-x-6">
              {[
                { href: "https://www.facebook.com/Youssef.Ibrahim004", icon: "📘", name: "Facebook", color: "blue-500" },
                { href: "https://www.instagram.com/ph_eljoo/", icon: "📷", name: "Instagram", color: "pink-500" },
                { href: "https://linkedin.com/in/youssef-ibrahim-gaber-abdellatif-011356335/", icon: "💼", name: "LinkedIn", color: "blue-600" }
              ].map((social, index) => (
                <a 
                  key={index}
                  href={social.href} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-16 h-16 rounded-full glass-morphism-strong flex items-center justify-center text-3xl hover-lift group relative overflow-hidden"
                  title={social.name}
                >
                  <span className="relative z-10 group-hover:scale-125 transition-all duration-300">{social.icon}</span>
                  <div className={`absolute inset-0 bg-gradient-to-r from-${social.color}/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-all duration-300 rounded-full`}></div>
                  <div className="absolute -inset-1 bg-gradient-to-r from-blue-400/30 to-cyan-400/30 rounded-full blur opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
